
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.

// The code based on on avs2yuv (by Loren Merritt) and the AVIS-input
// from x264 (http://www.videolan.org/developers/x264.html).

// You can use this software to encode videos using the 32-bit version
// of Avisynth with the 64-bit version of x264 under Windows (VfW).
// The x264 executable needs to be named x264_64.exe and placed in the
// same folder as this program.

//Compiling: gcc vfw4x264.c -lvfw32 -s -O2 -ovfw4x264

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <vfw.h>
#include <string.h>
#include <ctype.h>

#define X264_EXECUTABLE_NAME "x264_64"
#define PIPE_BUFFER_SIZE (DWORD)0//1048576 // values bigger than 250000 break the application


static int gcd( int a, int b )
{
    while (1)
    {
        int c = a % b;
        if ( !c )
            return b;
        a = b;
        b = c;
    }
}

char* generate_new_commadline(int argc, char *argv[], int i_frame_total, int i_fps_num, int i_fps_den, int i_width, int i_height, char* infile )
{
    int i;
    char *cmd, *buf;
    int len = (unsigned int)strrchr(argv[0], '\\');
    if (len)
    {
        len -=(unsigned int)argv[0];
        buf = malloc(len+2<20 ? 20: len+2);
        strncpy(buf, argv[0], len);
        buf[len] = '\\';
        buf[len+1] = 0;
    }
    else
    {
        buf = malloc(20);
        *buf=0;
    }
    cmd = malloc(8192);
    sprintf(cmd, "\"%s" X264_EXECUTABLE_NAME "\" --frames %d --fps %d/%d ", buf, i_frame_total, i_fps_num, i_fps_den);
    for (i=1;i<argc;i++)
    {
        if (infile!=argv[i])
        {
            if (strrchr(argv[i], ' '))
            {
                strcat(cmd, "\"");
                strcat(cmd, argv[i]);
                strcat(cmd, "\" ");
            }
            else
            {
                strcat(cmd, argv[i]);
                strcat(cmd, " ");
            }
        }
    }
    sprintf(buf, "- %dx%d", i_width, i_height);
    strcat(cmd, buf);
    free(buf);
    return cmd;
}


int main(int argc, char *argv[])
{
    //vfw related
    PAVISTREAM avi_stream;
    AVISTREAMINFO info;
    //createprocess related
    HANDLE h_process, h_stdOut, h_stdErr, h_pipeRead, h_pipeWrite;
    SECURITY_ATTRIBUTES saAttr;
    STARTUPINFO si_info;
    PROCESS_INFORMATION pi_info;
    DWORD exitcode = 0;
    /*Video Info*/
    int i_width;
    int i_height;
    int i_fps_num;
    int i_fps_den;
    int i_frame_total;
    /*Video Info End*/
    char *plane0, *plane1, *plane2;
    unsigned int frame,len,full_size,p1_size,p2_size;
    int i;
    char *cmd;
    char *infile = NULL;
    if (argc>1)
    {
        //get the script file
        for (i=1;i<argc;i++)
        {
            len =  strlen(argv[i]);
            if (len>4 && (argv[i][len-4])== '.' && tolower(argv[i][len-3])== 'a' && tolower(argv[i][len-2])== 'v' && tolower(argv[i][len-1])== 's')
            {
                infile=argv[i];
                break;
            }
        }
        if (!infile)
        {
            fprintf( stderr, "No avs script found.");
            return -1;
        }
        //open the script
        AVIFileInit();
        if ( AVIStreamOpenFromFile( &avi_stream, infile, streamtypeVIDEO, 0, OF_READ, NULL ) )
        {
            AVIFileExit();
            return -1;
        }

        if ( AVIStreamInfo(avi_stream, &info, sizeof(AVISTREAMINFO)) )
        {
            goto vfw_fail;
        }

        // check input format
        if (info.fccHandler != MAKEFOURCC('Y', 'V', '1', '2'))
        {
            fprintf( stderr, "avis [error]: unsupported input format (%c%c%c%c)\n",
                     (char)(info.fccHandler & 0xff), (char)((info.fccHandler >> 8) & 0xff),
                     (char)((info.fccHandler >> 16) & 0xff), (char)((info.fccHandler >> 24)) );
            goto vfw_fail;
        }

        i_width = info.rcFrame.right - info.rcFrame.left;

        i_height = info.rcFrame.bottom - info.rcFrame.top;
        i = gcd(info.dwRate, info.dwScale);
        i_fps_den = info.dwScale / i;
        i_fps_num = info.dwRate / i;
        i_frame_total = info.dwLength;

        
        //execute the commandline

        h_process = GetCurrentProcess();
        h_stdOut = GetStdHandle(STD_OUTPUT_HANDLE);
        h_stdErr = GetStdHandle(STD_ERROR_HANDLE);

        if (h_stdOut==INVALID_HANDLE_VALUE || h_stdErr==INVALID_HANDLE_VALUE)
        {
            fprintf( stderr, "Error: Couldn\'t get standard handles!");
            goto vfw_fail;
        }

        saAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
        saAttr.bInheritHandle = TRUE;
        saAttr.lpSecurityDescriptor = NULL;

        if (!CreatePipe(&h_pipeRead, &h_pipeWrite, &saAttr, PIPE_BUFFER_SIZE))
        {
            fprintf( stderr, "Error: Pipe creation failed!");
            goto vfw_fail;
        }

        if ( !SetHandleInformation(h_pipeWrite, HANDLE_FLAG_INHERIT, 0) )
        {
            fprintf( stderr, "Error: SetHandleInformation");
            goto pipe_fail;
        }

        ZeroMemory( &pi_info, sizeof(PROCESS_INFORMATION) );
        ZeroMemory( &si_info, sizeof(STARTUPINFO) );
        si_info.cb = sizeof(STARTUPINFO);
        si_info.dwFlags = STARTF_USESTDHANDLES;
        si_info.hStdInput = h_pipeRead;
        si_info.hStdOutput = h_stdOut;
        si_info.hStdError = h_stdErr;

		cmd = generate_new_commadline(argc, argv, i_frame_total, i_fps_num, i_fps_den, i_width, i_height, infile );
		
        if (!CreateProcess(NULL, cmd, NULL, NULL, TRUE, 0, NULL, NULL, &si_info, &pi_info))
        {
            fprintf( stderr, "Error: Failed to create process <%d>!", (int)GetLastError());
            free(cmd);
			goto pipe_fail;
        }
        CloseHandle(h_pipeRead);
        free(cmd);

        //prepare for writing
        p1_size = i_width*i_height;
        p2_size = p1_size/4;
        full_size = p1_size*3/2;//full size of a frame

        plane0 = malloc(full_size);
        plane2 = plane0+p1_size;
        plane1 = plane2+p2_size;
        //write
        for (frame=0; frame<i_frame_total; frame++)
        {
            AVIStreamRead(avi_stream, frame, 1, plane0, full_size, NULL, NULL );
            WriteFile(h_pipeWrite, plane0, p1_size, (PDWORD)&i, NULL);
            WriteFile(h_pipeWrite, plane1, p2_size, (PDWORD)&i, NULL);
            WriteFile(h_pipeWrite, plane2, p2_size, (PDWORD)&i, NULL);
        }
		free(plane0);
        //close & cleanup
        CloseHandle(h_pipeWrite);
		WaitForSingleObject(pi_info.hProcess, INFINITE);
        GetExitCodeProcess(pi_info.hProcess,&exitcode);
        CloseHandle(pi_info.hProcess);
		goto vfw_cleanup;// pipes already closed
		pipe_fail:
		CloseHandle(h_pipeRead);
		CloseHandle(h_pipeWrite);
		vfw_fail:
		exitcode = -1;
		vfw_cleanup:
        AVIStreamRelease(avi_stream);
        AVIFileExit();      
    }
    return exitcode;
}
